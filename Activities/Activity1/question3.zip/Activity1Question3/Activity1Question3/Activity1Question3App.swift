//
//  Activity1Question3App.swift
//  Activity1Question3
//
//  Created by Hunter Bowman on 8/29/21.
//

import SwiftUI

@main
struct Activity1Question3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView(firstName: "", lastName: "", greeting: "")
        }
    }
}
