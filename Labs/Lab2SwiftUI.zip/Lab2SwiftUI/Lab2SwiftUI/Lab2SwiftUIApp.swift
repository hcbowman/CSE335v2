//
//  Lab2SwiftUIApp.swift
//  Lab2SwiftUI
//
//  Created by Hunter Bowman on 9/12/21.
//

import SwiftUI

@main
struct Lab2SwiftUIApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
