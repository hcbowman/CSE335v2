//
//  Person.swift
//  Person
//
//  Created by Hunter Bowman on 9/12/21.
//

import Foundation

class Person: ObservableObject {
    @Published var weight:Float = 0.0
}
